# Notebook examples
## Prerequisites
For interactive matplotlib plots we use `ipympl` (`%matplotlib widget`). To install it run:
```bash
pip install ipympl
pip install ipywidgets
jupyter nbextension install --py widgetsnbextension --user
jupyter nbextension enable widgetsnbextension --user --py
```
